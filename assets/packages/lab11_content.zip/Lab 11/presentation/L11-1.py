class ComplexNumber(object):
    
    def __init__(self, a, b):
        self.real = a
        self.imaginary = b
    

c = ComplexNumber(3, 2)