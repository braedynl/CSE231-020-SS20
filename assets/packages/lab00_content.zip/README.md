# Lab 0

[Download this folder's content (*.zip file)](../assets/packages/lab00_content.zip). This will bring you to another page, click "View raw" or the "Download" button at the top-right once you're there. 

The submission page for all labs are on [Mimir](https://class.mimir.io/). You can submit an infinite amount of times before the deadline. The _best_ submission is graded by the TAs (i.e. the one that passes the most test-cases).

This lab simply has you set up Spyder and Python. There is also a [video made by Dr. Enbody](https://www.youtube.com/watch?v=_CqtctVJZnk&feature=youtu.be) if you'd prefer verbal instructions (there won't be lab videos from here on out).

There is no meeting/presentation associated with this lab. For all future labs, you'll do them in-class with me and your fellow classmates at the alloted section time (whether that be in-person or through Zoom).

If you have any questions, please don't hesitate to contact me (letting4@msu.edu)!
