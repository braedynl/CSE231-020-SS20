VOWELS = "aeiou"
word = input("Enter a word ('quit' to quit): ")
        
# Error message used in Mimir test
#print("Can't convert empty string.  Try again.")