def open_file():
	# insert doc string here
	pass

def str_plot(month,week,n,type):
	# insert doc string here
	pass
        
def convert(n):
	# insert doc string here
	pass

def month_name(n):
	# insert doc string here
	pass
   
def main():     
	# insert doc string here
	pass
        
if __name__ == '__main__':
    main()
