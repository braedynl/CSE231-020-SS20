
n = 3
for i in range(n): # 0 1 2, just 'stop' parameter
    print(i)
print()

for i in range(2, 5): # 2 3 4, 'start' and 'stop'
    print(i)
print() 

for i in range(1, 9, 2): # 1 3 5 7, 'start', 'stop', 'step'
    print(i)
print()

for letter in "word": # Iterate through the characters in a string
    print(letter)