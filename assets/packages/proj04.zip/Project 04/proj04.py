''' Insert heading comments here.'''


def display_options():
    ''' This function displays the menu of options'''

    MENU = '''\nPlease choose one of the options below:
             A. Convert a decimal number to another base system         
             B. Convert decimal number from another base.
             C. Convert from one representation system to another.
             D. Display the sum of two binary numbers.
             E. Compress an image.
             U. Uncompress an image.
             M. Display the menu of options.
             X. Exit from the program.'''
       
    print(MENU)
    
def numtobase( N, B ):
    '''Insert docstring here.'''
    pass  # insert your code here

def basetonum( S, B ):
    '''Insert docstring here.'''
    pass  # insert your code here

def basetobase(B1,B2,s_in_B1):
    '''Insert docstring here.'''
    pass  # insert your code here

def addbinary(S, T):
    '''Insert docstring here.'''
    pass  # insert your code here
    
 
def compress(S):
    '''Insert docstring here.'''
    pass  # insert your code here


def uncompress(S):
    '''Insert docstring here.'''
    pass  # insert your code here         

def main():
    BANNER = '''
        .    .        .      .             . .     .        .          .          .
         .                 .                    .                .
  .               A long time ago in a galaxy far, far away...   .
              .   A terrible civil war burns throughout the  .        .     .
                 galaxy: a rag-tag group of freedom fighters   .  .
     .       .  has risen from beneath the dark shadow of the            .
.        .     evil monster the Galactic Empire has become.                  .  .
    .      Outnumbered and outgunned,  the Rebellion burns across the   .    .
.      vast reaches of space and a thousand-thousand worlds, with only     .
    . their great courage - and the mystical power known as the Force -
     flaming a fire of hope. a                                    .

              .------.
            .'::::::' `.
            |: __   __ |
            | <__] [__>|
            `-.  __  .-'
              | |==| |
              | |==| |
           __.`-[..]-`\__
    _.--:``      ||   _``:::--._
   | |  |.      .:'  (o) ::|  | |
   |_|  |::..  // _       :|  |_|
    ===-|:``` // /.\       |-===
   |_| `:___//_|[ ]|_____.' |_| )
    l=l   |\V/_=======_==|   l=l/
  .-l=l   |`'==/=="======|  /|.:
  | l l   |=="======\=_==| `-T l
  `.l_l   |==============|   l_l
    [_]  [__][__]____[_]__]  [_]
    \\\ .'.--.- --   --. .`. |||.
    \\\\| |  |    |    |  || ||||
     \\\\   .'    |    |  |`.||||   
      \\\\  |  LS |    `.   |||||     


    
  ~~ Your mission: Tatooine planet is under attack from stormtroopers,
                   and there is only one line of defense remaining        
                   It is up to you to stop the invasion and save the planet~~    
                
    '''

    print(BANNER)
    
    pass  # insert your code here

if __name__ == "__main__": 
    main()